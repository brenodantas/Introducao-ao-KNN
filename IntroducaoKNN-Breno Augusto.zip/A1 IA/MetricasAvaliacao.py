import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.datasets import make_classification, load_iris, load_wine

# Função para realizar experimentos e calcular as métricas de avaliação
def run_experiments_and_evaluate(X, y, dataset_name):
    percentuais = [0.1, 0.2, 0.3, 0.4]
    k_values = [1, 3, 5, 7, 9]
    
    # Loop pelos percentuais de treino
    for perc in percentuais:
        print(f"\n--- Percentual de treino: {int(perc * 100)}% ---")
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=1-perc, random_state=42, stratify=y)
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Loop pelos valores de k
        for k in k_values:
            knn = KNeighborsClassifier(n_neighbors=k)
            knn.fit(X_train_scaled, y_train)
            y_pred = knn.predict(X_test_scaled)
            
            # Cálculo das métricas
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred, average='weighted')
            recall = recall_score(y_test, y_pred, average='weighted')
            f1 = f1_score(y_test, y_pred, average='weighted')
            conf_matrix = confusion_matrix(y_test, y_pred)
            
            print(f"k={k}:")
            print(f"  Acurácia: {accuracy:.2f}")
            print(f"  Precisão: {precision:.2f}")
            print(f"  Recall: {recall:.2f}")
            print(f"  F1-Score: {f1:.2f}")
            print(f"  Matriz de Confusão:\n{conf_matrix}\n")

# a) Dados Sintéticos 2D
print("Dados Sintéticos 2D:")
X_synthetic, y_synthetic = make_classification(n_samples=100, n_features=2, 
                                               n_informative=2, n_redundant=0, 
                                               n_repeated=0, n_classes=2, random_state=42)
run_experiments_and_evaluate(X_synthetic, y_synthetic, "Dados Sintéticos 2D")

# b) Base Iris
print("\nBase Iris:")
iris = load_iris()
X_iris, y_iris = iris.data, iris.target
run_experiments_and_evaluate(X_iris, y_iris, "Base Iris")

# c) Base Wine
print("\nBase Wine:")
wine = load_wine()
X_wine, y_wine = wine.data, wine.target
run_experiments_and_evaluate(X_wine, y_wine, "Base Wine")
