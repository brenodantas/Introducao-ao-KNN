import numpy as np
from collections import Counter

class KNN:
    def __init__(self, k=3):
        self.k = k

    def fit(self, X_train, y_train):
        self.X_train = X_train
        self.y_train = y_train

    def predict(self, X_test):
        predictions = [self._predict(x) for x in X_test]
        return np.array(predictions)

    def _predict(self, x):
        # Calcula as distâncias entre x e todos os exemplos no conjunto de treinamento
        distances = [np.linalg.norm(x - x_train) for x_train in self.X_train]
        # Ordena as distâncias e obtém os índices dos K vizinhos mais próximos
        k_indices = np.argsort(distances)[:self.k]
        # Obter os rótulos dos K vizinhos mais próximos
        k_nearest_labels = [self.y_train[i] for i in k_indices]
        # Retorna o rótulo mais comum
        most_common = Counter(k_nearest_labels).most_common(1)
        return most_common[0][0]

# Testando a implementação
if __name__ == "__main__":
    # Exemplo de dados simples
    X_train = np.array([[1, 2], [2, 3], [3, 1], [6, 5], [7, 8], [8, 6]])
    y_train = np.array([0, 0, 0, 1, 1, 1])
    X_test = np.array([[4, 4], [5, 5]])

    # Inicializando e treinando o modelo
    knn = KNN(k=3)
    knn.fit(X_train, y_train)

    # Fazendo previsões
    predictions = knn.predict(X_test)
    print("Previsões:", predictions)

