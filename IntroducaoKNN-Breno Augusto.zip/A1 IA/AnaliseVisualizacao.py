import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import f1_score
from sklearn.datasets import make_classification, load_iris, load_wine

# Função para gerar o gráfico de F1-Score em função de k e percentual de treinamento
def generate_f1_score_graph(X, y, dataset_name, custom_knn=None):
    percentuais = [0.1, 0.2, 0.3, 0.4]
    k_values = range(1, 10)
    
    plt.figure(figsize=(10, 6))
    
    for perc in percentuais:
        f1_scores = []
        
        # Divisão dos dados em treino e teste
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=1-perc, random_state=42, stratify=y)
        
        # Normalizando os dados
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        for k in k_values:
            # Implementação do scikit-learn
            if custom_knn is None:
                knn = KNeighborsClassifier(n_neighbors=k)
                knn.fit(X_train_scaled, y_train)
                y_pred = knn.predict(X_test_scaled)
            else:
                # Implementação personalizada
                custom_knn.fit(X_train_scaled, y_train)
                y_pred = custom_knn.predict(X_test_scaled, k)
            
            # Cálculo do F1-Score
            f1 = f1_score(y_test, y_pred, average='weighted')
            f1_scores.append(f1)
        
        # Plotando o F1-Score para o percentual de treino
        plt.plot(k_values, f1_scores, label=f'{int(perc * 100)}% treino')
    
    plt.title(f'F1-Score vs k para {dataset_name}')
    plt.xlabel('Número de Vizinhos (k)')
    plt.ylabel('F1-Score')
    plt.legend()
    plt.grid(True)
    plt.show()

# a) Dados Sintéticos 2D
X_synthetic, y_synthetic = make_classification(n_samples=100, n_features=2, 
                                               n_informative=2, n_redundant=0, 
                                               n_repeated=0, n_classes=2, random_state=42)
generate_f1_score_graph(X_synthetic, y_synthetic, "Dados Sintéticos 2D")

# b) Base Iris
iris = load_iris()
X_iris, y_iris = iris.data, iris.target
generate_f1_score_graph(X_iris, y_iris, "Base Iris")

# c) Base Wine
wine = load_wine()
X_wine, y_wine = wine.data, wine.target
generate_f1_score_graph(X_wine, y_wine, "Base Wine")
