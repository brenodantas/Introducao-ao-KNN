import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_classification, load_iris, load_wine
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Função para treinar o KNN e imprimir resultados
def train_knn(X, y, k=3):
    # Dividindo os dados em treino e teste
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
    
    # Normalizando os dados
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Inicializando o KNN
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train_scaled, y_train)
    
    # Previsões no conjunto de teste
    y_pred = knn.predict(X_test_scaled)
    
    # Acurácia
    accuracy = accuracy_score(y_test, y_pred)
    
    # Imprimir resultados
    print(f"Número de amostras no treino: {len(X_train)}")
    print(f"Número de amostras no teste: {len(X_test)}")
    print(f"Acurácia: {accuracy:.2f}")
    
    # Exemplo de previsões
    print(f"Previsões: {y_pred[:5]} (primeiras 5 amostras)")
    print(f"Valores Reais: {y_test[:5]} (primeiras 5 amostras)")

    # Retorna o modelo treinado e os dados de teste
    return knn, X_test_scaled, y_test

# a) Dados Sintéticos 2D
print("Dados Sintéticos 2D:")
X_synthetic, y_synthetic = make_classification(n_samples=100, n_features=2, 
                                               n_informative=2, n_redundant=0, 
                                               n_repeated=0, n_classes=2, random_state=42)
train_knn(X_synthetic, y_synthetic)

# b) Base Iris
print("\nBase Iris:")
iris = load_iris()
X_iris, y_iris = iris.data, iris.target
train_knn(X_iris, y_iris)

# c) Base Wine
print("\nBase Wine:")
wine = load_wine()
X_wine, y_wine = wine.data, wine.target
train_knn(X_wine, y_wine)
